
<a name="top"></a>
<a name="ref.BaseMenu"></a>
## BaseMenu

*BaseMenu* is the base class of many `*Menu` instances, factorizing features needed by many classes.

TODOC

