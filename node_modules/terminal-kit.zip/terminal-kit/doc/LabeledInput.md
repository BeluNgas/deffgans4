
<a name="top"></a>
<a name="ref.LabeledInput"></a>
## LabeledInput

TODOC
